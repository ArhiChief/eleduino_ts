#!/bin/sh

rmmod eleduino_ts.ko